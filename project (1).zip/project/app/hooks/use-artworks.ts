import { useState, useEffect } from "react";
import type { Artwork } from "~/data/artworks";
import { INITIAL_ARTWORKS } from "~/data/artworks";

const STORAGE_KEY = "ai-image-generator-images";

export function useArtworks() {
  const [artworks, setArtworks] = useState<Artwork[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        setArtworks(JSON.parse(stored));
      } catch {
        setArtworks(INITIAL_ARTWORKS);
      }
    } else {
      setArtworks(INITIAL_ARTWORKS);
    }
  }, []);

  const addArtwork = (artwork: Artwork) => {
    const updated = [artwork, ...artworks];
    setArtworks(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  };

  return { artworks, addArtwork };
}
