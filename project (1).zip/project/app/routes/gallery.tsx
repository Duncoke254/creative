import { useState } from "react";
import { Link } from "react-router";
import { ImageIcon, Sparkles } from "lucide-react";
import { Navigation } from "~/components/navigation";
import { useArtworks } from "~/hooks/use-artworks";
import { Dialog, DialogContent } from "~/components/ui/dialog/dialog";
import type { Artwork } from "~/data/artworks";
import styles from "./gallery.module.css";
import detailStyles from "./artwork-detail.module.css";

export default function Gallery() {
  const { artworks } = useArtworks();
  const [selectedArtwork, setSelectedArtwork] = useState<Artwork | null>(null);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const handleDownload = async (artwork: Artwork) => {
    try {
      const response = await fetch(artwork.imageUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      
      const link = document.createElement("a");
      link.href = url;
      link.download = `ai-canvas-${artwork.id}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download error:', error);
      // Fallback to opening in new tab
      window.open(artwork.imageUrl, '_blank');
    }
  };

  return (
    <div className={styles.page}>
      <Navigation />
      <div className={styles.container}>
        <div className={styles.header}>
          <h1 className={styles.title}>Your Photo Gallery</h1>
          <p className={styles.subtitle}>Explore your collection of AI-generated photos</p>
        </div>

        {artworks.length === 0 ? (
          <div className={styles.empty}>
            <ImageIcon className={styles.emptyIcon} />
            <h2 className={styles.emptyTitle}>No photos yet</h2>
            <p className={styles.emptyText}>Start creating your first AI-generated photo</p>
            <Link to="/" className={styles.emptyButton}>
              <Sparkles className={styles.buttonIcon} />
              Generate Photo
            </Link>
          </div>
        ) : (
          <div className={styles.grid}>
            {artworks.map((artwork) => (
              <div key={artwork.id} className={styles.card} onClick={() => setSelectedArtwork(artwork)}>
                <div className={styles.imageWrapper}>
                  <img src={artwork.imageUrl} alt={artwork.prompt} className={styles.image} />
                </div>
                <div className={styles.cardContent}>
                  <p className={styles.prompt}>{artwork.prompt}</p>
                  <div className={styles.meta}>
                    <span className={styles.style}>{artwork.style}</span>
                    <span className={styles.date}>{formatDate(artwork.createdAt)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Dialog open={!!selectedArtwork} onOpenChange={() => setSelectedArtwork(null)}>
        <DialogContent className={detailStyles.dialog}>
          {selectedArtwork && (
            <div className={detailStyles.content}>
              <div className={detailStyles.imageContainer}>
                <img src={selectedArtwork.imageUrl} alt={selectedArtwork.prompt} className={detailStyles.image} />
              </div>
              <div className={detailStyles.info}>
                <h2 className={detailStyles.prompt}>{selectedArtwork.prompt}</h2>
                <div className={detailStyles.meta}>
                  <span className={detailStyles.style}>{selectedArtwork.style}</span>
                  <span className={detailStyles.date}>{formatDate(selectedArtwork.createdAt)}</span>
                </div>
                <button
                  type="button"
                  className={detailStyles.downloadButton}
                  onClick={() => handleDownload(selectedArtwork)}
                >
                  Download Photo
                </button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
