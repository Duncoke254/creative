import { useState } from "react";
import { Sparkles, Download, ImageIcon } from "lucide-react";
import { Navigation } from "~/components/navigation";
import { useArtworks } from "~/hooks/use-artworks";
import { ART_STYLES } from "~/data/artworks";
import type { Artwork, ArtStyle } from "~/data/artworks";
import { toast } from "~/hooks/use-toast";
import styles from "./home.module.css";

// AI Image Generation API
const generateImageUrl = (prompt: string, style: ArtStyle): string => {
  // Using Pollinations.ai free API - no API key required
  const styleModifiers: Record<ArtStyle, string> = {
    "Photorealistic": "photorealistic, high detail, professional photography, 8k, ultra realistic, natural lighting",
    "Portrait": "professional portrait photography, studio lighting, detailed facial features, photorealistic, sharp focus, bokeh background",
    "Cinematic": "cinematic photography, film grain, dramatic lighting, photorealistic, professional, high quality",
    "Fashion": "fashion photography, professional model, studio lighting, high fashion, photorealistic, vogue style",
    "Street Photography": "street photography, candid moment, photorealistic, natural lighting, urban setting, documentary style",
    "Studio": "studio photography, professional lighting, clean background, photorealistic, commercial photography",
    "Natural Light": "natural light photography, golden hour, soft lighting, photorealistic, outdoor setting, authentic",
    "Black & White": "black and white photography, high contrast, photorealistic, professional, artistic, monochrome",
    "Magazine Cover": "magazine cover photography, professional, glamorous, photorealistic, high fashion, editorial style",
    "Lifestyle": "lifestyle photography, authentic moment, photorealistic, natural, environmental portrait, candid",
  };

  const enhancedPrompt = `${prompt}, ${styleModifiers[style]}`;
  const encodedPrompt = encodeURIComponent(enhancedPrompt);
  
  // Pollinations API generates unique images based on prompt
  return `https://image.pollinations.ai/prompt/${encodedPrompt}?width=1024&height=1024&seed=${Date.now()}&nologo=true`;
};

export default function Home() {
  const [prompt, setPrompt] = useState("");
  const [selectedStyle, setSelectedStyle] = useState<ArtStyle>("Photorealistic");
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentArtwork, setCurrentArtwork] = useState<Artwork | null>(null);
  const { addArtwork } = useArtworks();

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast({
        title: "Prompt required",
        description: "Please enter a description for your image",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);

    try {
      // Generate AI image URL based on prompt and style
      const imageUrl = generateImageUrl(prompt.trim(), selectedStyle);
      
      // Preload the image to ensure it's ready
      const img = new Image();
      img.src = imageUrl;
      
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = reject;
        // Timeout after 30 seconds
        setTimeout(() => reject(new Error('Image generation timeout')), 30000);
      });

      const artwork: Artwork = {
        id: Date.now().toString(),
        prompt: prompt.trim(),
        style: selectedStyle,
        imageUrl: imageUrl,
        createdAt: new Date().toISOString(),
      };

      setCurrentArtwork(artwork);
      addArtwork(artwork);
      setIsGenerating(false);

      toast({
        title: "Image generated!",
        description: "Your image has been created and saved to the gallery",
      });
    } catch (error) {
      setIsGenerating(false);
      toast({
        title: "Generation failed",
        description: "Failed to generate image. Please try again.",
        variant: "destructive",
      });
      console.error('Image generation error:', error);
    }
  };

  const handleDownload = async () => {
    if (!currentArtwork) return;

    try {
      const response = await fetch(currentArtwork.imageUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      
      const link = document.createElement("a");
      link.href = url;
      link.download = `ai-canvas-${currentArtwork.id}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast({
        title: "Download started",
        description: "Your image is being downloaded",
      });
    } catch (error) {
      toast({
        title: "Download failed",
        description: "Failed to download image. Please try right-clicking and saving the image.",
        variant: "destructive",
      });
      console.error('Download error:', error);
    }
  };

  return (
    <div className={styles.page}>
      <Navigation />
      <div className={styles.container}>
        <div className={styles.hero}>
          <h1 className={styles.title}>Generate Photorealistic Human Images with AI</h1>
          <p className={styles.subtitle}>Create realistic photos of people in any style or setting</p>
        </div>

        <div className={styles.content}>
          <div className={styles.formSection}>
            <h2 className={styles.formTitle}>Generate Your Image</h2>
            <div className={styles.form}>
              <div className={styles.fieldGroup}>
                <label htmlFor="prompt" className={styles.label}>
                  Describe Your Image
                </label>
                <textarea
                  id="prompt"
                  className={styles.textarea}
                  placeholder="e.g., 'Professional businesswoman smiling in office' or 'Young athlete running outdoors'..."
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  disabled={isGenerating}
                />
              </div>

              <div className={styles.fieldGroup}>
                <label className={styles.label}>Choose Image Style</label>
                <div className={styles.styleGrid}>
                  {ART_STYLES.map((style) => (
                    <button
                      key={style}
                      type="button"
                      className={`${styles.styleButton} ${selectedStyle === style ? styles.selected : ""}`}
                      onClick={() => setSelectedStyle(style)}
                      disabled={isGenerating}
                    >
                      {style}
                    </button>
                  ))}
                </div>
              </div>

              <button type="button" className={styles.generateButton} onClick={handleGenerate} disabled={isGenerating}>
                <Sparkles className={styles.buttonIcon} />
                {isGenerating ? "Generating..." : "Generate Image"}
              </button>
            </div>
          </div>

          <div className={styles.displaySection}>
            <div className={styles.displayCard}>
              <h2 className={styles.displayTitle}>Your Image</h2>
              <div className={styles.imageContainer}>
                {isGenerating && (
                  <div className={styles.loader}>
                    <div className={styles.spinner} />
                    <p className={styles.loadingText}>Creating your image with AI...</p>
                  </div>
                )}
                {!isGenerating && !currentArtwork && (
                  <div className={styles.placeholder}>
                    <ImageIcon className={styles.placeholderIcon} />
                    <p>Your generated image will appear here</p>
                  </div>
                )}
                {!isGenerating && currentArtwork && (
                  <img src={currentArtwork.imageUrl} alt={currentArtwork.prompt} className={styles.image} />
                )}
              </div>

              {currentArtwork && !isGenerating && (
                <div className={styles.artworkInfo}>
                  <p className={styles.artworkPrompt}>{currentArtwork.prompt}</p>
                  <div className={styles.artworkMeta}>
                    <span className={styles.artworkStyle}>{currentArtwork.style}</span>
                    <button type="button" className={styles.downloadButton} onClick={handleDownload}>
                      <Download className={styles.buttonIcon} />
                      Download
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
