export interface Artwork {
  id: string;
  prompt: string;
  style: string;
  imageUrl: string;
  createdAt: string;
}

// Helper function to generate AI image URLs
const generateAIImageUrl = (prompt: string, style: string, seed: number): string => {
  const styleModifiers: Record<string, string> = {
    "Photorealistic": "photorealistic, high detail, professional photography, 8k, ultra realistic, natural lighting",
    "Portrait": "professional portrait photography, studio lighting, detailed facial features, photorealistic, sharp focus, bokeh background",
    "Cinematic": "cinematic photography, film grain, dramatic lighting, photorealistic, professional, high quality",
    "Fashion": "fashion photography, professional model, studio lighting, high fashion, photorealistic, vogue style",
    "Street Photography": "street photography, candid moment, photorealistic, natural lighting, urban setting, documentary style",
    "Studio": "studio photography, professional lighting, clean background, photorealistic, commercial photography",
    "Natural Light": "natural light photography, golden hour, soft lighting, photorealistic, outdoor setting, authentic",
    "Black & White": "black and white photography, high contrast, photorealistic, professional, artistic, monochrome",
    "Magazine Cover": "magazine cover photography, professional, glamorous, photorealistic, high fashion, editorial style",
    "Lifestyle": "lifestyle photography, authentic moment, photorealistic, natural, environmental portrait, candid",
  };

  const enhancedPrompt = `${prompt}, ${styleModifiers[style] || 'photorealistic, high quality'}`;
  const encodedPrompt = encodeURIComponent(enhancedPrompt);
  return `https://image.pollinations.ai/prompt/${encodedPrompt}?width=1024&height=1024&seed=${seed}&nologo=true`;
};

export const INITIAL_ARTWORKS: Artwork[] = [
  {
    id: "1",
    prompt: "Professional headshot of a confident businesswoman in modern office",
    style: "Portrait",
    imageUrl: generateAIImageUrl("Professional headshot of a confident businesswoman in modern office", "Portrait", 1001),
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
  },
  {
    id: "2",
    prompt: "Young man smiling outdoors in casual clothing during golden hour",
    style: "Natural Light",
    imageUrl: generateAIImageUrl("Young man smiling outdoors in casual clothing during golden hour", "Natural Light", 1002),
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
  },
  {
    id: "3",
    prompt: "Fashion model in elegant dress on city street",
    style: "Fashion",
    imageUrl: generateAIImageUrl("Fashion model in elegant dress on city street", "Fashion", 1003),
    createdAt: new Date(Date.now() - 86400000 * 7).toISOString(),
  },
  {
    id: "4",
    prompt: "Athletic person running in urban environment at sunrise",
    style: "Lifestyle",
    imageUrl: generateAIImageUrl("Athletic person running in urban environment at sunrise", "Lifestyle", 1004),
    createdAt: new Date(Date.now() - 86400000 * 10).toISOString(),
  },
  {
    id: "5",
    prompt: "Elderly couple laughing together in park",
    style: "Photorealistic",
    imageUrl: generateAIImageUrl("Elderly couple laughing together in park", "Photorealistic", 1005),
    createdAt: new Date(Date.now() - 86400000 * 12).toISOString(),
  },
  {
    id: "6",
    prompt: "Professional chef preparing food in restaurant kitchen",
    style: "Cinematic",
    imageUrl: generateAIImageUrl("Professional chef preparing food in restaurant kitchen", "Cinematic", 1006),
    createdAt: new Date(Date.now() - 86400000 * 15).toISOString(),
  },
];

export const ART_STYLES = [
  "Photorealistic",
  "Portrait",
  "Cinematic",
  "Fashion",
  "Street Photography",
  "Studio",
  "Natural Light",
  "Black & White",
  "Magazine Cover",
  "Lifestyle",
] as const;

export type ArtStyle = (typeof ART_STYLES)[number];

export { generateAIImageUrl };
