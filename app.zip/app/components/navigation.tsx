import { NavLink } from "react-router";
import { Camera, ImageIcon } from "lucide-react";
import styles from "./navigation.module.css";

export function Navigation() {
  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <NavLink to="/" className={styles.brand}>
          <Camera className={styles.icon} />
          <span>AI Photo Generator</span>
        </NavLink>
        <nav className={styles.nav}>
          <NavLink to="/" end className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ""}`}>
            <Camera className={styles.navIcon} />
            <span>Generate</span>
          </NavLink>
          <NavLink to="/gallery" className={({ isActive }) => `${styles.navLink} ${isActive ? styles.active : ""}`}>
            <ImageIcon className={styles.navIcon} />
            <span>Gallery</span>
          </NavLink>
        </nav>
      </div>
    </header>
  );
}
